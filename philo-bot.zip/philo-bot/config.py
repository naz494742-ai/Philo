import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

PAYMENT_INSTRUCTIONS = os.getenv(
    "PAYMENT_INSTRUCTIONS",
    "Переведи 990 руб. на карту 0000 0000 0000 0000 "
    "(в комментарии к переводу укажи свой Telegram username) "
    "и нажми кнопку ниже.",
)

if not BOT_TOKEN:
    raise RuntimeError(
        "Не задан BOT_TOKEN. Скопируй .env.example в .env и впиши туда токен от @BotFather."
    )
