"""
Хранилище пользователей — SQLite вместо плоского JSON-файла.

Почему так надёжнее: JSON-версия читала и перезаписывала весь файл
целиком на каждую операцию — при одновременных запросах от нескольких
пользователей это риск повредить файл. SQLite обрабатывает параллельные
операции сам и не требует держать всех пользователей в памяти разом.
"""
import os
import logging
from datetime import datetime, timezone
from typing import Optional

import aiosqlite

logger = logging.getLogger(__name__)

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
DB_PATH = os.path.join(DATA_DIR, "bot.db")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    segment TEXT,
    last_lesson_id TEXT,
    last_lesson_time TEXT,
    paid INTEGER NOT NULL DEFAULT 0,
    awaiting_answer INTEGER NOT NULL DEFAULT 0,
    blocked INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS answers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    lesson_id TEXT,
    answer_text TEXT,
    created_at TEXT NOT NULL
);
"""

_ALLOWED_FIELDS = {
    "username", "segment", "last_lesson_id", "last_lesson_time",
    "paid", "awaiting_answer", "blocked",
}


async def init_db():
    """Вызывается один раз при старте бота — создаёт файл БД и таблицы, если их ещё нет."""
    os.makedirs(DATA_DIR, exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript(_SCHEMA)
        await db.commit()
    logger.info("База данных готова: %s", DB_PATH)


def _row_to_dict(row: aiosqlite.Row) -> dict:
    return {
        "user_id": row["user_id"],
        "username": row["username"],
        "segment": row["segment"],
        "last_lesson_id": row["last_lesson_id"],
        "last_lesson_time": row["last_lesson_time"],
        "paid": bool(row["paid"]),
        "awaiting_answer": bool(row["awaiting_answer"]),
        "blocked": bool(row["blocked"]),
        "created_at": row["created_at"],
    }


async def get_user(user_id: int) -> Optional[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        return _row_to_dict(row) if row else None


async def create_user(user_id: int, username: str = ""):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users (user_id, username, created_at) VALUES (?, ?, ?)",
            (user_id, username, datetime.now(timezone.utc).isoformat()),
        )
        await db.commit()


async def update_user(user_id: int, **fields):
    fields = {k: v for k, v in fields.items() if k in _ALLOWED_FIELDS}
    if not fields:
        return

    for key in ("paid", "awaiting_answer", "blocked"):
        if key in fields:
            fields[key] = int(bool(fields[key]))

    set_clause = ", ".join(f"{k} = ?" for k in fields)
    values = list(fields.values()) + [user_id]

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f"UPDATE users SET {set_clause} WHERE user_id = ?", values)
        await db.commit()


async def add_answer(user_id: int, lesson_id: str, text: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO answers (user_id, lesson_id, answer_text, created_at) VALUES (?, ?, ?, ?)",
            (user_id, lesson_id, text, datetime.now(timezone.utc).isoformat()),
        )
        await db.commit()


async def all_users() -> list[dict]:
    """Возвращает список всех пользователей — используется планировщиком."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM users")
        rows = await cursor.fetchall()
        return [_row_to_dict(r) for r in rows]
