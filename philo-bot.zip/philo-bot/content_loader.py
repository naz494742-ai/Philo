"""
Загрузка контента уроков из content/lessons.json.
Чтобы поменять текст урока, добавить новый или поправить формулировку —
редактируй content/lessons.json, код трогать не нужно.

При старте файл проверяется на целостность (все id из free_sequence/
paid_sequence должны реально существовать в lessons/paid_lessons) —
если контент сломан, бот сразу и понятно упадёт при старте, а не
где-то посреди рассылки уроков у случайного пользователя.
"""
import json
import os

_PATH = os.path.join(os.path.dirname(__file__), "content", "lessons.json")


def _load() -> dict:
    try:
        with open(_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError as e:
        raise RuntimeError(f"Не найден файл контента: {_PATH}") from e
    except json.JSONDecodeError as e:
        raise RuntimeError(f"content/lessons.json повреждён или содержит синтаксическую ошибку: {e}") from e

    _validate(data)
    return data


def _validate(data: dict):
    required_top_level = {"hook", "free_sequence", "lessons", "offer", "paid_sequence", "paid_lessons"}
    missing = required_top_level - data.keys()
    if missing:
        raise RuntimeError(f"В lessons.json не хватает ключей верхнего уровня: {missing}")

    for lesson_id in data["free_sequence"]:
        if lesson_id not in data["lessons"]:
            raise RuntimeError(f"free_sequence ссылается на урок '{lesson_id}', которого нет в lessons")

    for lesson_id in data["paid_sequence"]:
        if lesson_id not in data["paid_lessons"]:
            raise RuntimeError(f"paid_sequence ссылается на урок '{lesson_id}', которого нет в paid_lessons")

    for key in ("lessons", "paid_lessons"):
        for lesson_id, lesson in data[key].items():
            for field in ("title", "philosopher", "text"):
                if not lesson.get(field):
                    raise RuntimeError(f"Урок '{lesson_id}' в {key}: не заполнено поле '{field}'")


_DATA = _load()


def get_hook_text() -> str:
    return _DATA["hook"]["text"]


def get_free_sequence() -> list:
    return _DATA["free_sequence"]


def get_paid_sequence() -> list:
    return _DATA["paid_sequence"]


def get_offer_text() -> str:
    return _DATA["offer"]["text"]


def get_lesson(lesson_id: str, source: str = "free") -> dict | None:
    """source: 'free' или 'paid'"""
    key = "lessons" if source == "free" else "paid_lessons"
    return _DATA.get(key, {}).get(lesson_id)


def reload():
    """Перечитать и заново провалидировать lessons.json без перезапуска бота."""
    global _DATA
    _DATA = _load()
