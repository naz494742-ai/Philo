import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

import config
import storage
from logging_setup import setup_logging
from handlers import start, payment, admin, analysis, answers
from scheduler import setup_scheduler

setup_logging()
logger = logging.getLogger(__name__)


async def main():
    await storage.init_db()

    bot = Bot(
        token=config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())

    # Порядок регистрации важен: более специфичные обработчики — раньше,
    # универсальный "лови любой текст" (answers) — последним.
    dp.include_router(admin.router)
    dp.include_router(start.router)
    dp.include_router(payment.router)
    dp.include_router(analysis.router)
    dp.include_router(answers.router)

    scheduler = setup_scheduler(bot)

    try:
        logger.info("Бот запущен")
        await dp.start_polling(bot)
    finally:
        scheduler.shutdown(wait=False)
        await bot.session.close()
        logger.info("Бот остановлен")


if __name__ == "__main__":
    asyncio.run(main())
