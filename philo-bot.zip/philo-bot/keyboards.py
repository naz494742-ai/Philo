from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def start_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="Начать", callback_data="start_course")
    return builder.as_markup()


def segment_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="Работа", callback_data="segment_work")
    builder.button(text="Отношения", callback_data="segment_relationships")
    builder.button(text="Неопределённость будущего", callback_data="segment_future")
    builder.adjust(1)
    return builder.as_markup()


def payment_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="Оплатить доступ", callback_data="show_payment")
    return builder.as_markup()


def paid_confirm_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="Я оплатил(а)", callback_data="paid_confirm")
    return builder.as_markup()
