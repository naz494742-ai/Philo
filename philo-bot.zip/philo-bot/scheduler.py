"""
Раз в час проходит по всем пользователям и проверяет: не пора ли отправить
следующий урок (или оффер после последнего бесплатного урока).
Время ожидания между уроками задаётся полем unlock_after_hours в lessons.json.

Устойчивость: если пользователь заблокировал бота, Telegram на попытку
написать ему отвечает ошибкой TelegramForbiddenError — раньше это привело
бы к тому, что бот пытался бы писать ему каждый час и падал на этом же
месте. Теперь такой пользователь помечается blocked=True и больше не
трогается рассылкой.
"""
import logging
from datetime import datetime, timezone

from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError, TelegramBadRequest
from apscheduler.schedulers.asyncio import AsyncIOScheduler

import storage
import content_loader
from keyboards import payment_keyboard

logger = logging.getLogger(__name__)


async def check_and_send_lessons(bot: Bot):
    users = await storage.all_users()
    now = datetime.now(timezone.utc)
    logger.info("Проверка расписания уроков: %d пользователей в базе", len(users))

    for user in users:
        if user.get("blocked"):
            continue
        try:
            await _process_user(bot, user, now)
        except TelegramForbiddenError:
            logger.info("Пользователь %s заблокировал бота — помечаю и больше не пишу", user["user_id"])
            await storage.update_user(user["user_id"], blocked=True)
        except TelegramBadRequest as e:
            logger.warning("Telegram отклонил сообщение для %s: %s", user["user_id"], e)
        except Exception:
            logger.exception("Неожиданная ошибка при обработке пользователя %s", user["user_id"])


async def _process_user(bot: Bot, user: dict, now: datetime):
    user_id = user["user_id"]
    last_id = user.get("last_lesson_id")
    if last_id is None:
        return  # ещё не начал курс

    if last_id in ("offer_sent", "paid_sequence_done"):
        return

    if user.get("awaiting_answer"):
        return  # ждём ответа на упражнение

    source = "paid" if user.get("paid") else "free"
    sequence = content_loader.get_paid_sequence() if user.get("paid") else content_loader.get_free_sequence()

    if last_id not in sequence:
        logger.warning("У пользователя %s неизвестный урок '%s' — пропускаю", user_id, last_id)
        return

    last_time = user.get("last_lesson_time")
    if not last_time:
        return
    last_dt = datetime.fromisoformat(last_time)

    current_lesson = content_loader.get_lesson(last_id, source)
    wait_hours = current_lesson.get("unlock_after_hours", 24) if current_lesson else 24
    hours_passed = (now - last_dt).total_seconds() / 3600
    if hours_passed < wait_hours:
        return

    idx = sequence.index(last_id)
    is_last = idx == len(sequence) - 1

    if is_last:
        if not user.get("paid"):
            await bot.send_message(user_id, content_loader.get_offer_text(), reply_markup=payment_keyboard())
            await storage.update_user(user_id, last_lesson_id="offer_sent")
        else:
            await storage.update_user(user_id, last_lesson_id="paid_sequence_done")
        return

    next_id = sequence[idx + 1]
    lesson = content_loader.get_lesson(next_id, source)
    if not lesson:
        logger.error("Урок '%s' не найден в lessons.json", next_id)
        return

    text = f"<b>{lesson['title']}</b> ({lesson['philosopher']})\n\n{lesson['text']}"
    await bot.send_message(user_id, text)
    if lesson.get("exercise"):
        await bot.send_message(user_id, lesson["exercise"])

    await storage.update_user(
        user_id,
        last_lesson_id=next_id,
        last_lesson_time=now.isoformat(),
        awaiting_answer=bool(lesson.get("exercise")),
    )


def setup_scheduler(bot: Bot) -> AsyncIOScheduler:
    scheduler = AsyncIOScheduler(timezone="UTC")
    scheduler.add_job(
        check_and_send_lessons,
        "interval",
        hours=1,
        args=[bot],
        next_run_time=datetime.now(timezone.utc),  # первая проверка сразу при старте
    )
    scheduler.start()
    return scheduler
