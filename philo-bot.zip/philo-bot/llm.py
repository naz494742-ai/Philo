"""
Опциональная функция «разбери мою ситуацию».
Работает только если в .env задан ANTHROPIC_API_KEY.
Если ключа нет или API вернул ошибку — функция вежливо об этом сообщает,
остальной бот при этом продолжает работать как обычно.
"""
import logging

import config

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """Ты — ассистент курса по практическому стоицизму для тревожности.
Разбирай ситуацию пользователя, используя только идеи, уже разобранные в курсе:
- дихотомия контроля (Эпиктет)
- премедитацио малорум / представление худшего сценария (Сенека)
- взгляд сверху / масштаб (Марк Аврелий)
- «не вещи, а мнения о вещах» (Эпиктет)

Не придумывай других философских концепций и имён, которых нет в этом списке.
Пиши в тоне уроков курса: на "ты", короткими абзацами, сначала — понятный
житейский разбор, потом явная отсылка к одной из идей выше.
Обязательно заканчивай конкретным вопросом или маленьким действием, а не общим выводом."""


async def analyze_situation(user_text: str) -> str:
    if not config.ANTHROPIC_API_KEY:
        return (
            "Функция разбора ситуаций пока не подключена — "
            "чтобы включить, добавь ANTHROPIC_API_KEY в переменные окружения."
        )

    try:
        import anthropic
    except ImportError:
        logger.error("Библиотека anthropic не установлена, а ANTHROPIC_API_KEY задан")
        return "Для этой функции на сервере не установлена нужная библиотека."

    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)

    try:
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=600,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_text}],
        )
    except Exception:
        logger.exception("Ошибка при обращении к Anthropic API")
        return "Не получилось разобрать ситуацию — сервис ИИ сейчас недоступен, попробуй чуть позже."

    return "".join(block.text for block in response.content if block.type == "text")
