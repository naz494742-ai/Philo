from aiogram import Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message

import storage
from llm import analyze_situation

router = Router()


class AnalysisStates(StatesGroup):
    waiting_situation = State()


@router.message(Command("разбор"))
async def cmd_analysis(message: Message, state: FSMContext):
    user = await storage.get_user(message.from_user.id)
    if not user or not user.get("paid"):
        await message.answer("Эта функция доступна после оплаты курса.")
        return

    await message.answer(
        "Опиши своими словами, что сейчас тревожит — разберу через уже пройденные уроки."
    )
    await state.set_state(AnalysisStates.waiting_situation)


@router.message(AnalysisStates.waiting_situation)
async def handle_situation(message: Message, state: FSMContext):
    await message.answer("Секунду, думаю над этим...")
    result = await analyze_situation(message.text)
    await message.answer(result)
    await state.clear()
