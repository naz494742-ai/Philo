from aiogram import Router, F
from aiogram.types import CallbackQuery

import config
from keyboards import paid_confirm_keyboard

router = Router()


@router.callback_query(F.data == "show_payment")
async def show_payment(callback: CallbackQuery):
    await callback.message.answer(
        config.PAYMENT_INSTRUCTIONS,
        reply_markup=paid_confirm_keyboard(),
    )
    await callback.answer()


@router.callback_query(F.data == "paid_confirm")
async def paid_confirm(callback: CallbackQuery):
    user = callback.from_user
    await callback.message.answer(
        "Спасибо! Проверю оплату и открою доступ — обычно это занимает до пары часов."
    )
    if config.ADMIN_ID:
        username = f"@{user.username}" if user.username else "(без username)"
        await callback.bot.send_message(
            config.ADMIN_ID,
            f"💰 Новая оплата на подтверждение\n"
            f"ID: <code>{user.id}</code>\n"
            f"{username}\n\n"
            f"Чтобы открыть доступ, отправь команду:\n/grant {user.id}",
        )
    await callback.answer()
