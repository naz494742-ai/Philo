from datetime import datetime, timezone

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

import config
import storage
import content_loader

router = Router()


@router.message(Command("grant"))
async def grant_access(message: Message):
    """Использование (только для админа): /grant <user_id>"""
    if message.from_user.id != config.ADMIN_ID:
        return

    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        await message.answer("Использование: /grant <user_id>")
        return

    user_id = int(parts[1])
    user = await storage.get_user(user_id)
    if not user:
        await message.answer("Пользователь с таким ID не найден в базе.")
        return

    first_id = content_loader.get_paid_sequence()[0]
    lesson = content_loader.get_lesson(first_id, "paid")

    await storage.update_user(
        user_id,
        paid=True,
        last_lesson_id=first_id,
        last_lesson_time=datetime.now(timezone.utc).isoformat(),
        awaiting_answer=bool(lesson.get("exercise")),
    )

    await message.bot.send_message(
        user_id,
        "Доступ открыт 🎉 Дальше — 16 уроков по твоим темам. Первый уже здесь:",
    )
    text = f"<b>{lesson['title']}</b> ({lesson['philosopher']})\n\n{lesson['text']}"
    await message.bot.send_message(user_id, text)
    if lesson.get("exercise"):
        await message.bot.send_message(user_id, lesson["exercise"])

    await message.answer(f"Готово, доступ для {user_id} открыт.")
