from aiogram import Router, F
from aiogram.types import Message

import storage

router = Router()


@router.message(F.text & ~F.text.startswith("/"))
async def handle_free_text(message: Message):
    """
    Ловит любой обычный текст, который не подошёл под более специфичные обработчики
    (например, ответ на команду /разбор перехватывается раньше, т.к. этот роутер
    регистрируется последним в bot.py).
    """
    user = await storage.get_user(message.from_user.id)
    if not user:
        return

    if user.get("awaiting_answer"):
        await storage.add_answer(message.from_user.id, user.get("last_lesson_id"), message.text)
        await storage.update_user(message.from_user.id, awaiting_answer=False)
        await message.answer("Принято. Увидимся в следующем уроке 🙂")
