from datetime import datetime, timezone

from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery

import storage
import content_loader
from keyboards import start_keyboard, segment_keyboard

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    await storage.create_user(message.from_user.id, message.from_user.username or "")
    await message.answer(content_loader.get_hook_text(), reply_markup=start_keyboard())


@router.callback_query(F.data == "start_course")
async def start_course(callback: CallbackQuery):
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer(
        "Прежде чем начать — что сейчас тревожит больше всего?",
        reply_markup=segment_keyboard(),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("segment_"))
async def choose_segment(callback: CallbackQuery):
    segment = callback.data.replace("segment_", "")
    await storage.update_user(callback.from_user.id, segment=segment)
    await callback.message.edit_reply_markup(reply_markup=None)

    first_id = content_loader.get_free_sequence()[0]
    lesson = content_loader.get_lesson(first_id, "free")

    await _send_lesson(callback, lesson)

    await storage.update_user(
        callback.from_user.id,
        last_lesson_id=first_id,
        last_lesson_time=datetime.now(timezone.utc).isoformat(),
        awaiting_answer=bool(lesson.get("exercise")),
    )
    await callback.answer()


async def _send_lesson(callback: CallbackQuery, lesson: dict):
    text = f"<b>{lesson['title']}</b> ({lesson['philosopher']})\n\n{lesson['text']}"
    await callback.message.answer(text)
    if lesson.get("exercise"):
        await callback.message.answer(lesson["exercise"])
